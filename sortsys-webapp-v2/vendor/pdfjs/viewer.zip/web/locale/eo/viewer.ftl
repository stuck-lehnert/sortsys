# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Main toolbar buttons (tooltips and alt text for images)

pdfjs-previous-button =
    .title = Antaŭa paĝo
pdfjs-previous-button-label = Malantaŭen
pdfjs-next-button =
    .title = Venonta paĝo
pdfjs-next-button-label = Antaŭen
# .title: Tooltip for the pageNumber input.
pdfjs-page-input =
    .title = Paĝo
# Variables:
#   $pagesCount (Number) - the total number of pages in the document
# This string follows an input field with the number of the page currently displayed.
pdfjs-of-pages = el { $pagesCount }
# Variables:
#   $pageNumber (Number) - the currently visible page
#   $pagesCount (Number) - the total number of pages in the document
pdfjs-page-of-pages = ({ $pageNumber } el { $pagesCount })
pdfjs-zoom-out-button =
    .title = Malpligrandigi
pdfjs-zoom-out-button-label = Malpligrandigi
pdfjs-zoom-in-button =
    .title = Pligrandigi
pdfjs-zoom-in-button-label = Pligrandigi
pdfjs-zoom-select =
    .title = Pligrandigilo
pdfjs-presentation-mode-button =
    .title = Iri al prezenta reĝimo
pdfjs-presentation-mode-button-label = Prezenta reĝimo
pdfjs-open-file-button =
    .title = Malfermi dosieron
pdfjs-open-file-button-label = Malfermi
pdfjs-print-button =
    .title = Presi
pdfjs-print-button-label = Presi
pdfjs-save-button =
    .title = Konservi
pdfjs-save-button-label = Konservi
# Used in Firefox for Android as a tooltip for the download button (“download” is a verb).
pdfjs-download-button =
    .title = Elŝuti
# Used in Firefox for Android as a label for the download button (“download” is a verb).
# Length of the translation matters since we are in a mobile context, with limited screen estate.
pdfjs-download-button-label = Elŝuti
pdfjs-bookmark-button =
    .title = Nuna paĝo (Montri adreson de la nuna paĝo)
pdfjs-bookmark-button-label = Nuna paĝo

##  Secondary toolbar and context menu

pdfjs-tools-button =
    .title = Iloj
pdfjs-tools-button-label = Iloj
pdfjs-first-page-button =
    .title = Iri al la unua paĝo
pdfjs-first-page-button-label = Iri al la unua paĝo
pdfjs-last-page-button =
    .title = Iri al la lasta paĝo
pdfjs-last-page-button-label = Iri al la lasta paĝo
pdfjs-page-rotate-cw-button =
    .title = Rotaciigi dekstrume
pdfjs-page-rotate-cw-button-label = Rotaciigi dekstrume
pdfjs-page-rotate-ccw-button =
    .title = Rotaciigi maldekstrume
pdfjs-page-rotate-ccw-button-label = Rotaciigi maldekstrume
pdfjs-cursor-text-select-tool-button =
    .title = Aktivigi tekstan elektilon
pdfjs-cursor-text-select-tool-button-label = Teksta elektilo
pdfjs-cursor-hand-tool-button =
    .title = Aktivigi ilon de mano
pdfjs-cursor-hand-tool-button-label = Ilo de mano
pdfjs-scroll-page-button =
    .title = Uzi rulumon de paĝo
pdfjs-scroll-page-button-label = Rulumo de paĝo
pdfjs-scroll-vertical-button =
    .title = Uzi vertikalan rulumon
pdfjs-scroll-vertical-button-label = Vertikala rulumo
pdfjs-scroll-horizontal-button =
    .title = Uzi horizontalan rulumon
pdfjs-scroll-horizontal-button-label = Horizontala rulumo
pdfjs-scroll-wrapped-button =
    .title = Uzi ambaŭdirektan rulumon
pdfjs-scroll-wrapped-button-label = Ambaŭdirekta rulumo
pdfjs-spread-none-button =
    .title = Ne montri paĝojn po du
pdfjs-spread-none-button-label = Unupaĝa vido
pdfjs-spread-odd-button =
    .title = Kunigi paĝojn komencante per nepara paĝo
pdfjs-spread-odd-button-label = Po du paĝoj, neparaj maldekstre
pdfjs-spread-even-button =
    .title = Kunigi paĝojn komencante per para paĝo
pdfjs-spread-even-button-label = Po du paĝoj, paraj maldekstre

## Document properties dialog

pdfjs-document-properties-button =
    .title = Atributoj de dokumento…
pdfjs-document-properties-button-label = Atributoj de dokumento…
pdfjs-document-properties-file-name = Nomo de dosiero:
pdfjs-document-properties-file-size = Grando de dosiero:
# Variables:
#   $kb (Number) - the PDF file size in kilobytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-kb = { NUMBER($kb, maximumSignificantDigits: 3) } KO ({ $b } oktetoj)
# Variables:
#   $mb (Number) - the PDF file size in megabytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-mb = { NUMBER($mb, maximumSignificantDigits: 3) } Mo ({ $b } oktetoj)
pdfjs-document-properties-title = Titolo:
pdfjs-document-properties-author = Aŭtoro:
pdfjs-document-properties-subject = Temo:
pdfjs-document-properties-keywords = Ŝlosilvorto:
pdfjs-document-properties-creation-date = Dato de kreado:
pdfjs-document-properties-modification-date = Dato de modifo:
# Variables:
#   $dateObj (Date) - the creation/modification date and time of the PDF file
pdfjs-document-properties-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }
pdfjs-document-properties-creator = Kreinto:
pdfjs-document-properties-producer = Produktinto de PDF:
pdfjs-document-properties-version = Versio de PDF:
pdfjs-document-properties-page-count = Nombro de paĝoj:
pdfjs-document-properties-page-size = Grando de paĝo:
pdfjs-document-properties-page-size-unit-inches = in
pdfjs-document-properties-page-size-unit-millimeters = mm
pdfjs-document-properties-page-size-orientation-portrait = vertikala
pdfjs-document-properties-page-size-orientation-landscape = horizontala
pdfjs-document-properties-page-size-name-a-three = A3
pdfjs-document-properties-page-size-name-a-four = A4
pdfjs-document-properties-page-size-name-letter = Letera
pdfjs-document-properties-page-size-name-legal = Jura

## Variables:
##   $width (Number) - the width of the (current) page
##   $height (Number) - the height of the (current) page
##   $unit (String) - the unit of measurement of the (current) page
##   $name (String) - the name of the (current) page
##   $orientation (String) - the orientation of the (current) page

pdfjs-document-properties-page-size-dimension-string = { $width } × { $height } { $unit } ({ $orientation })
pdfjs-document-properties-page-size-dimension-name-string = { $width } × { $height } { $unit } ({ $name }, { $orientation })

##

# The linearization status of the document; usually called "Fast Web View" in
# English locales of Adobe software.
pdfjs-document-properties-linearized = Rapida tekstaĵa vido:
pdfjs-document-properties-linearized-yes = Jes
pdfjs-document-properties-linearized-no = Ne
pdfjs-document-properties-close-button = Fermi
pdfjs-digital-signature-properties-view-certificate = Vidi atestilon
# Shown beneath an invalid signature card to explain why verification
# failed. The text comes from NSS (e.g. "Signature integrity has been
# compromised", "PKCS#7 signature could not be parsed") and is not
# itself localized — it is the underlying error message produced by
# the verification backend.
# Variables:
#   $reason (String) - error message describing why the signature
#                      could not be verified.
pdfjs-digital-signature-properties-reason = Kialo: { $reason }
# Variables:
#   $dateObj (Date) - the signing time from the /Sig dict's /M entry.
pdfjs-digital-signature-properties-timestamp = Tempindiko: { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }
# Variables:
#   $count (Number) - number of nested sub-signatures (one per earlier
#                     incremental revision of the document).
pdfjs-digital-signature-properties-sub-signatures =
    { $count ->
        [one] Duaranga subskribo ({ $count })
       *[other] Duarangaj subskriboj ({ $count })
    }

## Print

pdfjs-print-progress-message = Preparo de dokumento por presi ĝin …
# Variables:
#   $progress (Number) - percent value
pdfjs-print-progress-percent = { $progress }%
pdfjs-print-progress-close-button = Nuligi
pdfjs-printing-not-supported = Averto: tiu ĉi retumilo ne plene subtenas presadon.
pdfjs-printing-not-ready = Averto: la PDF dosiero ne estas plene ŝargita por presado.

## Tooltips and alt text for side panel toolbar buttons

pdfjs-current-outline-item-button =
    .title = Trovi nunan konturan elementon
pdfjs-current-outline-item-button-label = Nuna kontura elemento
pdfjs-findbar-button =
    .title = Serĉi en dokumento
pdfjs-findbar-button-label = Serĉi
pdfjs-additional-layers = Aldonaj tavoloj

## Thumbnails panel item (tooltip and alt text for images)

# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-canvas =
    .aria-label = Miniaturo de paĝo { $page }
# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-checkbox1 =
    .title = Elekti paĝon { $page }
# Variables:
#   $page (Number) - the page number
#   $total (Number) - the number of pages
pdfjs-thumb-page-title1 =
    .title = Paĝo { $page } el { $total }

## Find panel button title and messages

pdfjs-find-input =
    .placeholder = Serĉi en dokumento…
    .title = Serĉi
pdfjs-find-previous-button =
    .title = Serĉi la antaŭan aperon de la frazo
pdfjs-find-previous-button-label = Malantaŭen
pdfjs-find-next-button =
    .title = Serĉi la venontan aperon de la frazo
pdfjs-find-next-button-label = Antaŭen
pdfjs-find-highlight-checkbox = Elstarigi ĉiujn
pdfjs-find-match-case-checkbox-label = Distingi usklecon
pdfjs-find-match-diacritics-checkbox-label = Respekti supersignojn
pdfjs-find-entire-word-checkbox-label = Tutaj vortoj
pdfjs-find-reached-top = Komenco de la dokumento atingita, daŭrigado ekde la fino
pdfjs-find-reached-bottom = Fino de la dokumento atingita, daŭrigado ekde la komenco
# Variables:
#   $current (Number) - the index of the currently active find result
#   $total (Number) - the total number of matches in the document
pdfjs-find-match-count =
    { $total ->
        [one] { $current } el { $total } kongruo
       *[other] { $current } el { $total } kongruoj
    }
# Variables:
#   $limit (Number) - the maximum number of matches
pdfjs-find-match-count-limit =
    { $limit ->
        [one] Pli ol { $limit } kongruo
       *[other] Pli ol { $limit } kongruoj
    }
pdfjs-find-not-found = Frazo ne trovita

## Predefined zoom values

pdfjs-page-scale-width = Larĝo de paĝo
pdfjs-page-scale-fit = Adapti paĝon
pdfjs-page-scale-auto = Aŭtomata skalo
pdfjs-page-scale-actual = Reala grando
# Variables:
#   $scale (Number) - percent value for page scale
pdfjs-page-scale-percent = { $scale }%

## PDF page

# Variables:
#   $page (Number) - the page number
pdfjs-page-landmark =
    .aria-label = Paĝo { $page }

## Loading indicator messages

pdfjs-loading-error = Okazis eraro dum la ŝargado de la PDF dosiero.
pdfjs-invalid-file-error = Nevalida aŭ difektita PDF dosiero.
pdfjs-missing-file-error = Mankas dosiero PDF.
pdfjs-unexpected-response-error = Neatendita respondo de servilo.
pdfjs-rendering-error = Okazis eraro dum la montro de la paĝo.

## Annotations

# .alt: This is used as a tooltip.
# Variables:
#   $type (String) - an annotation type from a list defined in the PDF spec
# (32000-1:2008 Table 169 – Annotation types).
# Some common types are e.g.: "Check", "Text", "Comment", "Note"
pdfjs-text-annotation-type =
    .alt = [Prinoto: { $type }]
# Variables:
#   $dateObj (Date) - the modification date and time of the annotation
pdfjs-annotation-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }

## Password

pdfjs-password-label = Tajpu pasvorton por malfermi tiun ĉi dosieron PDF.
pdfjs-password-invalid = Nevalida pasvorto. Bonvolu provi denove.
pdfjs-password-ok-button = Akcepti
pdfjs-password-cancel-button = Nuligi
pdfjs-web-fonts-disabled = Neaktivaj teksaĵaj tiparoj: ne elbas uzi enmetitajn tiparojn de PDF.

## Editing

pdfjs-editor-free-text-button =
    .title = Teksto
pdfjs-editor-color-picker-free-text-input =
    .title = Ŝanĝi koloron de teksto
pdfjs-editor-free-text-button-label = Teksto
pdfjs-editor-ink-button =
    .title = Desegni
pdfjs-editor-color-picker-ink-input =
    .title = Ŝanĝi desegnan koloron
pdfjs-editor-ink-button-label = Desegni
pdfjs-editor-stamp-button =
    .title = Aldoni aŭ modifi bildojn
pdfjs-editor-stamp-button-label = Aldoni aŭ modifi bildojn
pdfjs-editor-highlight-button =
    .title = Elstarigi
pdfjs-editor-highlight-button-label = Elstarigi
pdfjs-highlight-floating-button1 =
    .aria-label = Elstarigi
    .title = Elstarigi
pdfjs-highlight-floating-button-label = Elstarigi
pdfjs-comment-floating-button =
    .aria-label = Komenti
    .title = Komenti
pdfjs-comment-floating-button-label = Komenti
pdfjs-editor-comment-button =
    .aria-label = Komenti
    .title = Komenti
pdfjs-editor-comment-button-label = Komenti
pdfjs-editor-signature-button =
    .title = Aldoni subskribon
pdfjs-editor-signature-button-label = Aldoni subskribon

## Default editor aria labels

# “Highlight” is a noun, the string is used on the editor for highlights.
pdfjs-editor-highlight-editor =
    .aria-label = Redaktilo de elstaraĵo
# “Drawing” is a noun, the string is used on the editor for drawings.
pdfjs-editor-ink-editor =
    .aria-label = Redaktilo de desegno
# Used when a signature editor is selected/hovered.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-signature-editor1 =
    .aria-description = Redaktilo de subskribo: { $description }
pdfjs-editor-stamp-editor =
    .aria-label = Redaktilo de bildo

## Remove button for the various kind of editor.

pdfjs-editor-remove-ink-button =
    .title = Forigi desegnon
pdfjs-editor-remove-freetext-button =
    .title = Forigi tekston
pdfjs-editor-remove-stamp-button =
    .title = Forigi bildon
pdfjs-editor-remove-highlight-button =
    .title = Forigi elstaraĵon
pdfjs-editor-remove-signature-button =
    .title = Forigi subskribon

##

# Editor Parameters
pdfjs-editor-free-text-color-input = Koloro
pdfjs-editor-free-text-size-input = Grando
pdfjs-editor-ink-color-input = Koloro
pdfjs-editor-ink-thickness-input = Dikeco
pdfjs-editor-ink-opacity-input = Maldiafaneco
pdfjs-editor-stamp-add-image-button =
    .title = Aldoni bildon
pdfjs-editor-stamp-add-image-button-label = Aldoni bildon
# This refers to the thickness of the line used for free highlighting (not bound to text)
pdfjs-editor-free-highlight-thickness-input = Dikeco
pdfjs-editor-free-highlight-thickness-title =
    .title = Ŝanĝi dikecon dum elstarigo de netekstaj elementoj
pdfjs-editor-add-signature-container =
    .aria-label = Kontrolado de subskriboj kaj konservitaj subskriboj
pdfjs-editor-signature-add-signature-button =
    .title = Aldoni novan subskribon
pdfjs-editor-signature-add-signature-button-label = Aldoni novan subskribon
# Used on the button to use an already saved signature.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-add-saved-signature-button =
    .title = Konservita subskribo: { $description }
# .default-content is used as a placeholder in an empty text editor.
pdfjs-free-text2 =
    .aria-label = Teksta redaktilo
    .default-content = Komencu tajpi…
# Used to show how many comments are present in the pdf file.
# Variables:
#   $count (Number) - the number of comments.
pdfjs-editor-comments-sidebar-title =
    { $count ->
        [one] Komenti
       *[other] Komentoj
    }
pdfjs-editor-comments-sidebar-close-button =
    .aria-label = Fermi la flankan strion
    .title = Fermi la flankan strion
pdfjs-editor-comments-sidebar-close-button-label = Fermi la flankan strion
# Instructional copy to add a comment by selecting text or an annotations.
pdfjs-editor-comments-sidebar-no-comments1 = Ĉu vi rimarkas ion interesan? Elstarigu tion kaj aldonu komenton.
pdfjs-editor-comments-sidebar-no-comments-link = Pli da informo

## Alt-text dialog

pdfjs-editor-alt-text-button-label = Alternativa teksto
pdfjs-editor-alt-text-edit-button =
    .aria-label = Redakti alternativan tekston
pdfjs-editor-alt-text-dialog-label = Elektu eblon
pdfjs-editor-alt-text-dialog-description = Alternativa teksto helpas personojn, en la okazoj kiam ili ne povas vidi aŭ ŝargi la bildon.
pdfjs-editor-alt-text-add-description-label = Aldoni priskribon
pdfjs-editor-alt-text-add-description-description = La celo estas unu aŭ du frazoj, kiuj priskribas la temon, etoson aŭ agojn.
pdfjs-editor-alt-text-mark-decorative-label = Marki kiel ornaman
pdfjs-editor-alt-text-mark-decorative-description = Tio ĉi estas uzita por ornamaj bildoj, kiel randoj aŭ fonaj bildoj.
pdfjs-editor-alt-text-cancel-button = Nuligi
pdfjs-editor-alt-text-save-button = Konservi
pdfjs-editor-alt-text-decorative-tooltip = Markita kiel ornama
# .placeholder: This is a placeholder for the alt text input area
pdfjs-editor-alt-text-textarea =
    .placeholder = Ekzemple: “Juna persono sidiĝas ĉetable por ekmanĝi”
# Alternative text (alt text) helps when people can't see the image.
pdfjs-editor-alt-text-button =
    .aria-label = Alternativa teksto

## Editor resizers
## This is used in an aria label to help to understand the role of the resizer.

pdfjs-editor-resizer-top-left =
    .aria-label = Supra maldekstra angulo — ŝangi grandon
pdfjs-editor-resizer-top-middle =
    .aria-label = Supra mezo — ŝanĝi grandon
pdfjs-editor-resizer-top-right =
    .aria-label = Supran dekstran angulon — ŝanĝi grandon
pdfjs-editor-resizer-middle-right =
    .aria-label = Dekstra mezo — ŝanĝi grandon
pdfjs-editor-resizer-bottom-right =
    .aria-label = Malsupra deksta angulo — ŝanĝi grandon
pdfjs-editor-resizer-bottom-middle =
    .aria-label = Malsupra mezo — ŝanĝi grandon
pdfjs-editor-resizer-bottom-left =
    .aria-label = Malsupra maldekstra angulo — ŝanĝi grandon
pdfjs-editor-resizer-middle-left =
    .aria-label = Maldekstra mezo — ŝanĝi grandon

## Color picker

# This means "Color used to highlight text"
pdfjs-editor-highlight-colorpicker-label = Elstarigi koloron
pdfjs-editor-colorpicker-button =
    .title = Ŝanĝi koloron
pdfjs-editor-colorpicker-dropdown =
    .aria-label = Elekto de koloroj
pdfjs-editor-colorpicker-yellow =
    .title = Flava
pdfjs-editor-colorpicker-green =
    .title = Verda
pdfjs-editor-colorpicker-blue =
    .title = Blua
pdfjs-editor-colorpicker-pink =
    .title = Roza
pdfjs-editor-colorpicker-red =
    .title = Ruĝa

## Show all highlights
## This is a toggle button to show/hide all the highlights.

pdfjs-editor-highlight-show-all-button-label = Montri ĉiujn
pdfjs-editor-highlight-show-all-button =
    .title = Montri ĉiujn

## New alt-text dialog
## Group note for entire feature: Alternative text (alt text) helps when people can't see the image. This feature includes a tool to create alt text automatically using an AI model that works locally on the user's device to preserve privacy.

# Modal header positioned above a text box where users can edit the alt text.
pdfjs-editor-new-alt-text-dialog-edit-label = Modifi alternativan tekston (priskribo de bildo)
# Modal header positioned above a text box where users can add the alt text.
pdfjs-editor-new-alt-text-dialog-add-label = Aldoni alternativan tekston (priskribo de bildo)
pdfjs-editor-new-alt-text-textarea =
    .placeholder = Skribu vian priskribon ĉi tie…
# This text refers to the alt text box above this description. It offers a definition of alt text.
pdfjs-editor-new-alt-text-description = Mallonga priskribo por personoj kiuj ne povas vidi la bildon kaj por montri kiam la bildo ne ŝargeblas.
# This is a required legal disclaimer that refers to the automatically created text inside the alt text box above this text. It disappears if the text is edited by a human.
pdfjs-editor-new-alt-text-disclaimer1 = Tiu ĉi alternativa teksto estis aŭtomate kreita kaj povus esti malĝusta.
pdfjs-editor-new-alt-text-disclaimer-learn-more-url = Pli da informo
pdfjs-editor-new-alt-text-create-automatically-button-label = Aŭtomate krei alternativan tekston
pdfjs-editor-new-alt-text-not-now-button = Ne nun
pdfjs-editor-new-alt-text-error-title = Ne eblis aŭtomate krei alternativan tekston
pdfjs-editor-new-alt-text-error-description = Bonvolu skribi vian propran alternativan tekston aŭ provi denove poste.
pdfjs-editor-new-alt-text-error-close-button = Fermi
# Variables:
#   $totalSize (Number) - the total size (in MB) of the AI model.
#   $downloadedSize (Number) - the downloaded size (in MB) of the AI model.
pdfjs-editor-new-alt-text-ai-model-downloading-progress = Elŝuto de modelo de artefarita intelekto por alternativa teksto ({ $downloadedSize } el { $totalSize } MO)
    .aria-valuetext = Elŝuto de modelo de artefarita intelekto por alternativa teksto ({ $downloadedSize } el { $totalSize } MO)
# This is a button that users can click to edit the alt text they have already added.
pdfjs-editor-new-alt-text-added-button =
    .aria-label = Alternativa teksto aldonita
pdfjs-editor-new-alt-text-added-button-label = Alternativa teksto aldonita
# This is a button that users can click to open the alt text editor and add alt text when it is not present.
pdfjs-editor-new-alt-text-missing-button =
    .aria-label = Mankas alternativa teksto
pdfjs-editor-new-alt-text-missing-button-label = Mankas alternativa teksto
# This is a button that opens up the alt text modal where users should review the alt text that was automatically generated.
pdfjs-editor-new-alt-text-to-review-button =
    .aria-label = Kontroli alternativan tekston
pdfjs-editor-new-alt-text-to-review-button-label = Kontroli alternativan tekston
# "Created automatically" is a prefix that will be added to the beginning of any alt text that has been automatically generated. After the colon, the user will see/hear the actual alt text description. If the alt text has been edited by a human, this prefix will not appear.
# Variables:
#   $generatedAltText (String) - the generated alt-text.
pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer = Aŭtomate kreita: { $generatedAltText }

## Image alt-text settings

pdfjs-image-alt-text-settings-button =
    .title = Agordoj por alternativa teksto de bildoj
pdfjs-image-alt-text-settings-button-label = Agordoj por alternativa teksto de bildoj
pdfjs-editor-alt-text-settings-dialog-label = Agordoj por alternativa teksto de bildoj
pdfjs-editor-alt-text-settings-automatic-title = Aŭtomata alternativa teksto
pdfjs-editor-alt-text-settings-create-model-button-label = Aŭtomate krei alternativan tekston
pdfjs-editor-alt-text-settings-create-model-description = Tio ĉi sugestas priskribojn por helpi personojn kiuj ne povas vidi aŭ ŝargi la bildon.
pdfjs-editor-alt-text-settings-editor-title = Redaktilo de alternativa teksto
pdfjs-editor-alt-text-settings-show-dialog-button-label = Montri redaktilon de alternativa teksto tuj post aldono de bildo
pdfjs-editor-alt-text-settings-show-dialog-description = Tio ĉi helpas vin kontroli ĉu ĉiuj bildoj havas alternativan tekston.
pdfjs-editor-alt-text-settings-close-button = Fermi

## Accessibility labels (announced by screen readers) for objects added to the editor.

pdfjs-editor-highlight-added-alert = Elstarigo aldonita
pdfjs-editor-freetext-added-alert = Teksto aldonita
pdfjs-editor-ink-added-alert = Desegno aldonita
pdfjs-editor-stamp-added-alert = Bildo aldonita
pdfjs-editor-signature-added-alert = Subskribo aldonita

## "Annotations removed" bar

pdfjs-editor-undo-bar-message-highlight = Elstaraĵo forigita
pdfjs-editor-undo-bar-message-freetext = Teksto forigita
pdfjs-editor-undo-bar-message-ink = Desegno forigita
pdfjs-editor-undo-bar-message-stamp = Bildo forigita
pdfjs-editor-undo-bar-message-signature = Subskribo forigita
pdfjs-editor-undo-bar-message-comment = Komento forigita
# Variables:
#   $count (Number) - the number of removed annotations.
pdfjs-editor-undo-bar-message-multiple =
    { $count ->
        [one] unu prinoto forigita
       *[other] { $count } prinotoj forigitaj
    }
pdfjs-editor-undo-bar-undo-button =
    .title = Malfari
pdfjs-editor-undo-bar-undo-button-label = Malfari
pdfjs-editor-undo-bar-close-button =
    .title = Fermi
pdfjs-editor-undo-bar-close-button-label = Fermi

## Add a signature dialog

pdfjs-editor-add-signature-dialog-label = Tiu ĉi fenestro permesas al la uzanto krei subskribon por aldoni al dokumento PDF. La uzanto povas modifi la nomon (kiu estas cetere la alternativa teksto) kaj havas la eblon konservi la subskribon por posta uzo.
pdfjs-editor-add-signature-dialog-title = Aldoni subskribon

## Tab names

# Type is a verb (you can type your name as signature)
pdfjs-editor-add-signature-type-button = Tajpi
    .title = Tajpi
# Draw is a verb (you can draw your signature)
pdfjs-editor-add-signature-draw-button = Desegni
    .title = Desegni
pdfjs-editor-add-signature-image-button = Bildo
    .title = Bildo

## Tab panels

pdfjs-editor-add-signature-type-input =
    .aria-label = Tajpu vian subskribon
    .placeholder = Tajpu vian subskribon
pdfjs-editor-add-signature-draw-placeholder = Desegni vian subskribon
pdfjs-editor-add-signature-draw-thickness-range-label = Dikeco
# Variables:
#   $thickness (Number) - the thickness (in pixels) of the line used to draw a signature.
pdfjs-editor-add-signature-draw-thickness-range =
    .title = Dikeco de desegno: { $thickness }
pdfjs-editor-add-signature-image-placeholder = Trenu dosieron ĉi tien por alŝuti ĝin
pdfjs-editor-add-signature-image-browse-link =
    { PLATFORM() ->
        [macos] Aŭ elektu bildan dosieron
       *[other] Aŭ elektu bildan dosieron
    }

## Controls

pdfjs-editor-add-signature-description-label = Priskribo (alternativa teksto)
pdfjs-editor-add-signature-description-input =
    .title = Priskribo (alternativa teksto)
pdfjs-editor-add-signature-description-default-when-drawing = Subskribo
pdfjs-editor-add-signature-clear-button-label = Viŝi subskribon
pdfjs-editor-add-signature-clear-button =
    .title = Viŝi subskribon
pdfjs-editor-add-signature-save-checkbox = Konservi subskribon
pdfjs-editor-add-signature-save-warning-message = Vi atingis la limon de kvin konservitaj subskriboj. Forigi unu por povi konservi pli da.
pdfjs-editor-add-signature-image-upload-error-title = Ne eblis alŝuti bildon
pdfjs-editor-add-signature-image-upload-error-description = Kontrolu vian retaliron aŭ provu alŝuti alian bildon.
pdfjs-editor-add-signature-image-no-data-error-title = Ne eblas konverti tiun ĉi bildon al subskribo
pdfjs-editor-add-signature-image-no-data-error-description = Bonvolu provi alŝuti novan bildon.
pdfjs-editor-add-signature-error-close-button = Fermi

## Dialog buttons

pdfjs-editor-add-signature-cancel-button = Nuligi
pdfjs-editor-add-signature-add-button = Aldoni
pdfjs-editor-edit-signature-update-button = Ĝisdatigi

## Comment popup

pdfjs-editor-edit-comment-popup-button-label = Modifi komenton
pdfjs-editor-edit-comment-popup-button =
    .title = Modifi komenton
pdfjs-editor-delete-comment-popup-button-label = Forigi komenton
pdfjs-editor-delete-comment-popup-button =
    .title = Forigi komenton
pdfjs-show-comment-button =
    .title = Montri komenton

##  Edit a comment dialog

# An existing comment is edited
pdfjs-editor-edit-comment-dialog-title-when-editing = Modifi komenton
pdfjs-editor-edit-comment-dialog-save-button-when-editing = Ĝisdatigi
# No existing comment
pdfjs-editor-edit-comment-dialog-title-when-adding = Aldoni komenton
pdfjs-editor-edit-comment-dialog-save-button-when-adding = Aldoni
pdfjs-editor-edit-comment-dialog-text-input =
    .placeholder = Ektajpi…
pdfjs-editor-edit-comment-dialog-cancel-button = Nuligi

## Edit a comment button in the editor toolbar

pdfjs-editor-add-comment-button =
    .title = Aldoni komenton

## The view manager is a sidebar displaying different views:
##  - thumbnails;
##  - outline;
##  - attachments;
##  - layers.
## The thumbnails view is used to edit the pdf: remove/insert pages, ...

pdfjs-toggle-views-manager-notification-button =
    .title = Montri/kaŝi flankan strion (la dokumento enhavas miniaturojn/konturon/kunsendaĵojn/tavolojn)
pdfjs-toggle-views-manager-button1-label = Administri paĝojn
pdfjs-views-manager-sidebar =
    .aria-label = Flanka strio
pdfjs-views-manager-sidebar-resizer =
    .aria-label = Dimensiigilo por la flanka strio
pdfjs-views-manager-view-selector-button =
    .title = Vidoj
pdfjs-views-manager-view-selector-button-label = Vidoj
pdfjs-views-manager-pages-title = Paĝoj
pdfjs-views-manager-outlines-title1 = Konturo de dokumento
    .title = Konturo de dokumento (alklaku duoble por faldi/malfaldi ĉiujn elementojn)
pdfjs-views-manager-attachments-title = Kunsendaĵoj
pdfjs-views-manager-layers-title1 = Tavoloj
    .title = Tavoloj (alklaku duoble por ke ĉiuj tavoloj reiru al la norma stato)
pdfjs-views-manager-pages-option-label = Paĝoj
pdfjs-views-manager-outlines-option-label = Konturo de dokumento
pdfjs-views-manager-attachments-option-label = Kunsendaĵoj
pdfjs-views-manager-layers-option-label = Tavoloj
pdfjs-views-manager-add-file-button =
    .title = Aldoni dosieron
pdfjs-views-manager-add-file-button-label = Aldoni dosieron
# Variables:
#   $count (Number) - the number of selected pages.
pdfjs-views-manager-pages-status-action-label =
    { $count ->
        [one] { $count } elektita
       *[other] { $count } elektitaj
    }
pdfjs-views-manager-pages-status-none-action-label = Elekti paĝojn
pdfjs-views-manager-pages-status-action-button-label = Administri
pdfjs-views-manager-pages-status-copy-button-label = Kopii
pdfjs-views-manager-pages-status-cut-button-label = Eltondi
pdfjs-views-manager-pages-status-delete-button-label = Forigi
pdfjs-views-manager-pages-status-export-selected-button-label = Eksporti elektitajn…
# Variables:
#   $count (Number) - the number of selected pages to be cut.
pdfjs-views-manager-status-undo-cut-label =
    { $count ->
        [one] 1 paĝo eltondita
       *[other] { $count } paĝoj eltonditaj
    }
# Variables:
#   $count (Number) - the number of selected pages to be copied.
pdfjs-views-manager-pages-status-undo-copy-label =
    { $count ->
        [one] 1 paĝo kopiita
       *[other] { $count } paĝoj kopiitaj
    }
# Variables:
#   $count (Number) - the number of selected pages to be deleted.
pdfjs-views-manager-pages-status-undo-delete-label =
    { $count ->
        [one] 1 paĝo forigita
       *[other] { $count } paĝoj forigitaj
    }
pdfjs-views-manager-pages-status-waiting-ready-label = Pretigo de via dosiero…
pdfjs-views-manager-pages-status-waiting-uploading-label = Dosiero alŝutata…
pdfjs-views-manager-status-warning-cut-label = Ne eblis eltondi. Refreŝigu la paĝon kaj provu denove.
pdfjs-views-manager-status-warning-copy-label = Ne eblis kopii. Refreŝigu la paĝon kaj provu denove.
pdfjs-views-manager-status-warning-delete-label = Ne eblis forigi. Refreŝigu la paĝon kaj provu denove.
pdfjs-views-manager-status-warning-save-label = Ne eblis konservi. Refreŝigu la paĝon kaj provu denove.
pdfjs-views-manager-status-undo-button-label = Malfari
pdfjs-views-manager-status-done-button-label = Farita
pdfjs-views-manager-status-close-button =
    .title = Fermi
pdfjs-views-manager-status-close-button-label = Fermi
pdfjs-views-manager-paste-button-label = Alglui
pdfjs-views-manager-paste-button-before =
    .title = Alglui antaŭ la unua paĝo
# Variables:
#   $page (Number) - the page number after which the paste button is.
pdfjs-views-manager-paste-button-after =
    .title = Alglui post la paĝo { $page }
# Badge used to promote a new feature in the UI, keep it as short as possible.
# It's spelled uppercase for English, but it can be translated as usual.
pdfjs-new-badge-content = NOVA
pdfjs-views-manager-waiting-for-file = Dosiero alŝutata…
pdfjs-toggle-views-manager-button1 =
    .title = Administri paĝojn

## Digital signature properties (signature verification panel)

pdfjs-digital-signature-properties-button =
    .aria-label = Atributoj de cifereca subskribo
    .title = Atributoj de cifereca subskribo
pdfjs-digital-signature-properties-button-label = Atributoj de cifereca subskribo

## Banner shown above the signature list summarising the overall
## verification state of the document. Each variant is selected by the
## viewer based on the worst per-signature status; one signature is
## enough to lower the banner.
##
## Variables:
##   $count (Number) - number of signatures at the worst level.

pdfjs-digital-signature-properties-banner-verified = La dokumento estis subskribita de valida cifereca subskribo
pdfjs-digital-signature-properties-banner-unknown =
    { $count ->
        [one] Dokumento subskribita, tamen { $count } cifereca subskribo ne povis esti kontrolita
       *[other] Dokumento subskribita, tamen { $count } ciferecaj subskriboj ne povis esti kontrolita
    }
pdfjs-digital-signature-properties-banner-untrusted =
    { $count ->
        [one] Dokumento subskribita de { $count } nefidata atestilo
       *[other] Dokumento subskribita de { $count } nefidataj atestiloj
    }
pdfjs-digital-signature-properties-banner-expired =
    { $count ->
        [one] Dokumento subskribita de { $count } senvalidiĝinta atestilo
       *[other] Dokumento subskribita de { $count } senvalidiĝintaj atestiloj
    }
pdfjs-digital-signature-properties-banner-invalid =
    { $count ->
        [one] La dokumento havas { $count } nevalidan ciferecan subskribon
       *[other] La dokumento havas { $count } nevalidajn ciferecajn subskribojn
    }
pdfjs-digital-signature-properties-banner-revoked =
    { $count ->
        [one] Dokumento subskribita de { $count } senvalidigita atestilo
       *[other] Dokumento subskribita de { $count } senvalidigitaj atestiloj
    }

## Per-signature status row. Only three distinct strings are needed:
## the signature crypto either verified (the cert chain may still be
## untrusted/expired/revoked, but that's surfaced on the cert row
## below), or it failed, or its sub-format isn't supported.

pdfjs-digital-signature-properties-status-verified = Stato: Subskribo kontrolita
pdfjs-digital-signature-properties-status-invalid = Stato: Subskribo nevalida
pdfjs-digital-signature-properties-status-unknown = Stato: Ne eblas kontroli (nesubtenata)

## Per-signature certificate row. The variants with an issuer / date in
## parentheses embed fully-localized context — no English fall-through.
##
## Variables:
##   $issuer (String) - issuer or subject common name from the cert.
##   $dateObj (Date)  - notAfter date for the expired-with-date form.

pdfjs-digital-signature-properties-certificate-trusted = Atestilo: Fidata ({ $issuer })
pdfjs-digital-signature-properties-certificate-unknown = Atestilo: Nedisponebla
pdfjs-digital-signature-properties-certificate-untrusted = Atestilo: Ne fidata
pdfjs-digital-signature-properties-certificate-untrusted-unknown-issuer = Atestilo: Nekonata eldoninto ({ $issuer })
pdfjs-digital-signature-properties-certificate-untrusted-self-signed = Atestilo: Memsubskribita ({ $issuer })
pdfjs-digital-signature-properties-certificate-untrusted-untrusted-issuer = Atestilo: Nefidata eldoninto ({ $issuer })
pdfjs-digital-signature-properties-certificate-expired = Atestilo: Senvalidiĝinta
pdfjs-digital-signature-properties-certificate-expired-with-date = Atestilo: Senvalidiĝinta ({ DATETIME($dateObj, dateStyle: "medium") })
pdfjs-digital-signature-properties-certificate-revoked = Atestilo: Senvalidigita

## Main menu for adding/removing signatures

pdfjs-editor-delete-signature-button1 =
    .title = Forigi konservitan subskribon
pdfjs-editor-delete-signature-button-label1 = Forigi konservitan subskribon

## Editor toolbar

pdfjs-editor-add-signature-edit-button-label = Modifi priskribon

## Edit signature description dialog

pdfjs-editor-edit-signature-dialog-title = Modifi priskribon
